package org.tms.dao;



import org.tms.beans.Traineecls;
public interface Searchtrainee {
     Traineecls search(String userId);
}
