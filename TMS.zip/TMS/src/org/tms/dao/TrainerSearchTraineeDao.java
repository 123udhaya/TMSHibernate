package org.tms.dao;



public interface TrainerSearchTraineeDao {

	String TrainerSearchTrainee(String traineeId, String skillType);
}
