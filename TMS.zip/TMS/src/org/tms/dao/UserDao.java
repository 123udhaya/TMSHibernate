package org.tms.dao;

import org.tms.beans.User;
public interface UserDao {

	public String validateUser(User user);
}
