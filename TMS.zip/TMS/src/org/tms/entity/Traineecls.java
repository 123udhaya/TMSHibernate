package org.tms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class Traineecls implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	// @GeneratedValue(strategy=GenerationType.AUTO)
	 @Column(name = "uid")
	private String userId;
	@Column(name = "Designation")
	private String designation;
	@Column(name = "vertical")
	private String vertical;
	@Column(name = "Location")
	private String location;
	@Column(name = "phone")
	private String phone;
	@Column(name = "role")
	private String role;
	@Column(name = "fname")
	private String fname;
	@Column(name = "lname")
	private String lname;
	@Column(name = "date")
	private String date;
	@Column(name = "trainer")
	private String trainer;
	public Traineecls() {
		
	}
	
	public Traineecls(String userId,String fname, String lname, String date, String vertical, String designation,String location, String phone, String role,String trainer) {
		super();
		this.userId = userId;
		this.date = date;
		this.designation=designation;
		this.vertical = vertical;
		this.location = location;
		this.phone = phone;
		this.role = role;
		this.fname = fname;
		this.lname = lname;
		this.date = date;
		this.trainer = trainer;
	}

	

	

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getVertical() {
		return vertical;
	}

	public void setVertical(String vertical) {
		this.vertical = vertical;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTrainer() {
		return trainer;
	}

	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}

}
